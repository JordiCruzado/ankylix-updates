# Implementation Checklist

## ✅ Files to Add to Your Xcode Project

Add these 6 new files to your Xcode project:

1. ☐ **SwitcherTheme.swift** - Theme model for Window Switcher
2. ☐ **SwitcherThemeStore.swift** - Store for Window Switcher themes
3. ☐ **SwitcherThemesListView.swift** - UI for managing Window Switcher themes
4. ☐ **MoveResizeTheme.swift** - Theme model for Move/Resize
5. ☐ **MoveResizeThemeStore.swift** - Store for Move/Resize themes
6. ☐ **MoveResizeThemesListView.swift** - UI for managing Move/Resize themes

## ✅ Files Already Modified

These files have been updated with theme functionality:

1. ✓ **WindowSwitcherAppearanceView.swift** - Added theme save/load/manage
2. ✓ **MoveResizeAppearanceView.swift** - Added theme save/load/manage

## ✅ Build Steps

1. ☐ Add all 6 new files to your Xcode project
2. ☐ Ensure all files are added to your app target
3. ☐ Build the project (⌘B)
4. ☐ Fix any import or dependency issues if they arise
5. ☐ Run the app

## ✅ Testing Checklist

### Window Switcher Appearance Tab
1. ☐ Open Preferences → Window Switcher Appearance
2. ☐ Adjust some appearance settings
3. ☐ Click "Save Current Theme" or press ⌘S
4. ☐ Enter a theme name (e.g., "My Custom Switcher")
5. ☐ Click "Save"
6. ☐ Change the settings to something different
7. ☐ Click "Manage Themes…"
8. ☐ Verify your saved theme appears in the list
9. ☐ Click "Apply" on your theme
10. ☐ Verify settings are restored correctly
11. ☐ Test "Rename" functionality
12. ☐ Test "Delete" functionality

### Move/Resize Appearance Tab
1. ☐ Open Preferences → Move/Resize Appearance
2. ☐ Adjust some appearance settings
3. ☐ Click "Save Current Theme" or press ⌘S
4. ☐ Enter a theme name (e.g., "My Custom MR")
5. ☐ Click "Save"
6. ☐ Change the settings to something different
7. ☐ Click "Manage Themes…"
8. ☐ Verify your saved theme appears in the list
9. ☐ Click "Apply" on your theme
10. ☐ Verify settings are restored correctly
11. ☐ Test "Rename" functionality
12. ☐ Test "Delete" functionality

### Independence Verification
1. ☐ Save a theme in Layout Appearance tab
2. ☐ Save a theme in Window Switcher tab
3. ☐ Save a theme in Move/Resize tab
4. ☐ Open "Manage Themes…" in each tab
5. ☐ Verify each tab shows only its own themes
6. ☐ Verify themes from one tab don't appear in others

### Persistence Testing
1. ☐ Save several themes in each tab
2. ☐ Quit the app completely
3. ☐ Relaunch the app
4. ☐ Open preferences for each tab
5. ☐ Click "Manage Themes…" in each tab
6. ☐ Verify all saved themes are still there

## ✅ Common Issues & Solutions

### Issue: "Cannot find 'SwitcherTheme' in scope"
**Solution:** Make sure SwitcherTheme.swift is added to your target

### Issue: "Cannot find 'MoveResizeTheme' in scope"
**Solution:** Make sure MoveResizeTheme.swift is added to your target

### Issue: "Cannot find 'Color(hex:)'"
**Solution:** Verify ColorExtension.swift is in your project (it should already exist)

### Issue: "Cannot find 'LabelPosition'"
**Solution:** Verify AppereanceModel.swift is in your project (it should already exist)

### Issue: Themes not persisting
**Solution:** Check UserDefaults is working correctly; verify no sandbox issues

### Issue: Sheet not appearing when clicking "Manage Themes…"
**Solution:** Check that `showThemesList` state is properly bound to the sheet

## ✅ Features Implemented

### Window Switcher Themes Include:
- ✓ Border color and background
- ✓ Border width and radius
- ✓ Label text color, background, and border
- ✓ Label text size, border radius, and bold setting
- ✓ Label position
- ✓ Show window info toggle
- ✓ Default display mode

### Move/Resize Themes Include:
- ✓ Selection frame color, border width, and glow
- ✓ Snap target frame color, border width, and glow
- ✓ Corner radius
- ✓ Snap enabled, threshold, resistance
- ✓ Move step size

### UI Features:
- ✓ Save current theme (⌘S shortcut)
- ✓ Manage themes modal
- ✓ Apply themes
- ✓ Rename themes
- ✓ Delete themes
- ✓ Color previews in theme list
- ✓ Creation date display
- ✓ Theme count display
- ✓ Empty state when no themes saved

## 🎉 Success Criteria

Your implementation is successful when:

1. ✓ You can save themes in Window Switcher tab
2. ✓ You can save themes in Move/Resize tab
3. ✓ Themes persist across app restarts
4. ✓ Themes are independent between tabs
5. ✓ You can apply, rename, and delete themes
6. ✓ The UI is consistent with Layout Appearance tab
7. ✓ Keyboard shortcut ⌘S works for saving themes

## 📝 Notes

- All themes are stored in UserDefaults
- Storage keys are unique per tab
- Themes cannot be shared between tabs (by design)
- Each theme stores complete settings for its respective tab
- The implementation follows the same pattern as Layout Appearance
